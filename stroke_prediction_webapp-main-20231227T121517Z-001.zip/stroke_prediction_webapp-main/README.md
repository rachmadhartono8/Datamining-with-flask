# stroke_prediction_webapp
A Stroke Prediction Web-App Built Using Decision Tree Classifier and Flask
